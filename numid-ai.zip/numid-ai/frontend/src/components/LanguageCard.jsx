/* LanguageCard.jsx — displays an ancient language with its metadata */
export default function LanguageCard({ lang, selected, onClick }) {
  return (
    <button
      className={`lang-card ${selected ? "lang-card--selected" : ""}`}
      onClick={onClick}
      style={{ "--accent": lang.color }}
    >
      <div className="lang-card__glyphs">{lang.sample_glyphs}</div>
      <div className="lang-card__name">{lang.name}</div>
      <div className="lang-card__era">{lang.era}</div>
      <div className="lang-card__tags">
        <span className="tag tag-gold">{lang.direction.toUpperCase()}</span>
        <span className="tag tag-aqua">{lang.status}</span>
      </div>

      <style>{`
        .lang-card {
          position: relative;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 12px;
          padding: 16px;
          cursor: pointer;
          text-align: left;
          transition: all 0.2s;
          width: 100%;
          overflow: hidden;
        }
        .lang-card::before {
          content: '';
          position: absolute;
          inset: 0;
          border-radius: 12px;
          border: 2px solid transparent;
          transition: border-color 0.2s;
        }
        .lang-card:hover { background: var(--surface2); transform: translateY(-2px); }
        .lang-card:hover::before { border-color: var(--accent, var(--gold)); }
        .lang-card--selected { background: var(--surface2); }
        .lang-card--selected::before { border-color: var(--accent, var(--gold)) !important; }
        .lang-card--selected .lang-card__name { color: var(--accent, var(--gold)); }
        .lang-card__glyphs {
          font-size: 20px;
          letter-spacing: 2px;
          color: var(--accent, var(--gold));
          margin-bottom: 8px;
          opacity: 0.85;
          filter: drop-shadow(0 0 4px var(--accent, var(--gold)));
        }
        .lang-card__name {
          font-family: var(--font-display);
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 1px;
          color: var(--text);
          margin-bottom: 3px;
          transition: color 0.2s;
        }
        .lang-card__era {
          font-family: var(--font-mono);
          font-size: 9px;
          letter-spacing: 1px;
          color: var(--text-muted);
          margin-bottom: 8px;
        }
        .lang-card__tags { display: flex; gap: 4px; flex-wrap: wrap; }
      `}</style>
    </button>
  );
}

/* TranslationResult.jsx — renders the full AI translation output */
import { useState } from "react";

export default function TranslationResult({ result, lang }) {
  const [showWordBreakdown, setShowWordBreakdown] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!result) return null;
  const d = result;
  const isRTL = lang?.direction === "rtl";

  const copy = () => {
    navigator.clipboard.writeText(d.script_rendering || d.translated_text || "");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const confidenceColor = {
    high: "var(--sage)",
    medium: "var(--amber)",
    low: "var(--rose)",
  }[d.confidence] || "var(--text-dim)";

  return (
    <div className="tr-root animate-fadeInUp">
      {/* Script Display */}
      <div className="tr-hero">
        <div className="tr-hero__label section-label">
          {lang?.script || "Script"}
        </div>
        <div
          className={`script-display animate-glow ${isRTL ? "rtl" : ""}`}
          style={{ color: lang?.color || "var(--gold-light)" }}
        >
          {d.script_rendering || d.translated_text}
        </div>
        <div className="transliteration">/{d.transliteration}/</div>
        <div className="ipa">{d.ipa_pronunciation}</div>
        <div className="tr-hero__actions">
          <button className="btn btn-ghost" onClick={copy} style={{ fontSize: 11 }}>
            {copied ? "✓ Copied" : "⎘ Copy Script"}
          </button>
          <span className="tag" style={{
            background: `${confidenceColor}18`,
            color: confidenceColor,
            border: `1px solid ${confidenceColor}40`,
            fontSize: 10,
          }}>
            {d.confidence?.toUpperCase()} CONFIDENCE
          </span>
        </div>
      </div>

      <hr className="divider" />

      {/* Cultural Notes */}
      {d.cultural_notes && (
        <div className="tr-section">
          <div className="section-label">Cultural Notes</div>
          <p className="tr-prose">{d.cultural_notes}</p>
        </div>
      )}

      {/* Fun Fact */}
      {d.fun_fact && (
        <div className="tr-fact">
          <span className="tr-fact__icon">𓂋</span>
          <p>{d.fun_fact}</p>
        </div>
      )}

      {/* Confidence reason */}
      {d.confidence_reason && (
        <div className="tr-note">
          <span style={{ color: confidenceColor }}>ⓘ</span> {d.confidence_reason}
        </div>
      )}

      {/* Word Breakdown */}
      {d.word_breakdown && d.word_breakdown.length > 0 && (
        <div className="tr-section">
          <button
            className="btn btn-ghost"
            onClick={() => setShowWordBreakdown(!showWordBreakdown)}
            style={{ fontSize: 11, marginBottom: 12 }}
          >
            {showWordBreakdown ? "▲" : "▼"} Word-by-Word Breakdown ({d.word_breakdown.length} words)
          </button>
          {showWordBreakdown && (
            <div className="tr-breakdown">
              {d.word_breakdown.map((w, i) => (
                <div key={i} className="tr-word">
                  <div className="tr-word__script" style={{ color: lang?.color || "var(--gold)" }}>
                    {w.script}
                  </div>
                  <div className="tr-word__phonetic">/{w.phonetic}/</div>
                  <div className="tr-word__original">"{w.original_word}"</div>
                  <div className="tr-word__translation">{w.translation}</div>
                  {w.notes && <div className="tr-word__notes">{w.notes}</div>}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <style>{`
        .tr-root { display: flex; flex-direction: column; gap: 20px; }
        .tr-hero {
          background: var(--surface2);
          border: 1px solid rgba(200,168,75,0.15);
          border-radius: 14px;
          padding: 28px;
        }
        .tr-hero__actions { display: flex; align-items: center; gap: 12px; margin-top: 20px; }
        .tr-section { display: flex; flex-direction: column; gap: 8px; }
        .tr-prose { color: var(--text-dim); font-size: 15px; line-height: 1.7; }
        .tr-fact {
          display: flex;
          gap: 14px;
          align-items: flex-start;
          padding: 16px 20px;
          background: var(--gold-dim);
          border: 1px solid rgba(200,168,75,0.2);
          border-radius: 10px;
          font-size: 14px;
          color: var(--text-dim);
          line-height: 1.6;
        }
        .tr-fact__icon { font-size: 20px; color: var(--gold); flex-shrink: 0; }
        .tr-note {
          font-family: var(--font-mono);
          font-size: 11px;
          color: var(--text-muted);
          line-height: 1.6;
          padding: 10px 14px;
          border-left: 2px solid var(--border-glow);
        }
        .tr-breakdown {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
          gap: 12px;
          animation: fadeInUp 0.3s ease;
        }
        .tr-word {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 10px;
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .tr-word__script { font-size: 22px; letter-spacing: 2px; }
        .tr-word__phonetic { font-family: var(--font-mono); font-size: 11px; color: var(--aqua); }
        .tr-word__original { font-size: 11px; color: var(--text-muted); font-style: italic; }
        .tr-word__translation { font-size: 13px; color: var(--text); font-weight: 500; }
        .tr-word__notes { font-size: 11px; color: var(--text-muted); margin-top: 4px; }
      `}</style>
    </div>
  );
}

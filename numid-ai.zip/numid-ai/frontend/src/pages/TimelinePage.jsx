/* pages/TimelinePage.jsx — visual historical timeline of ancient languages */
import { useState, useEffect } from "react";
import { useLanguages } from "../hooks/useTranslation";

const ERA_ORDER = [
  "4th–3rd Millennium BCE",
  "2nd Millennium BCE",
  "1st Millennium BCE",
  "1st Millennium CE",
];

const ERA_COLORS = {
  "4th–3rd Millennium BCE": "#c8a84b",
  "2nd Millennium BCE": "#8B4513",
  "1st Millennium BCE": "#4A7C9E",
  "1st Millennium CE": "#6B8E6B",
};

export default function TimelinePage() {
  const { languages, fetchLanguages, loading } = useLanguages();
  const [selected, setSelected] = useState(null);

  useEffect(() => { fetchLanguages(); }, [fetchLanguages]);

  // Group by era
  const byEra = {};
  ERA_ORDER.forEach(e => byEra[e] = []);
  languages.forEach(lang => {
    for (const era of ERA_ORDER) {
      // heuristic matching
      if (lang.era.includes("BCE") && era.includes("BCE")) {
        const match = ERA_ORDER.find(e => {
          if (lang.era.includes("3500") || lang.era.includes("3000")) return e === "4th–3rd Millennium BCE";
          if (lang.era.includes("1400") || lang.era.includes("1500") || lang.era.includes("1200") || lang.era.includes("1900") || lang.era.includes("1450") || lang.era.includes("2800")) return e === "2nd Millennium BCE";
          if (lang.era.includes("1050") || lang.era.includes("800") || lang.era.includes("700") || lang.era.includes("600") || lang.era.includes("75")) return e === "1st Millennium BCE";
          return false;
        });
        if (match) { byEra[match].push(lang); break; }
      }
    }
  });
  // fallback: put remaining in 1st Millennium CE
  const placed = new Set(Object.values(byEra).flat().map(l => l.id));
  languages.forEach(lang => {
    if (!placed.has(lang.id)) byEra["1st Millennium CE"].push(lang);
  });

  return (
    <div className="tl-root">
      <div className="tl-header">
        <h1 className="tl-title">Language Timeline</h1>
        <p className="tl-sub">From the first marks scratched in clay to the alphabets that shaped civilization.</p>
      </div>

      {loading && <div style={{ textAlign: "center", padding: 60 }}><span className="loader" /></div>}

      <div className="tl-container">
        {/* Vertical spine */}
        <div className="tl-spine" />

        {ERA_ORDER.map((era, eraIndex) => {
          const langs = byEra[era] || [];
          if (!langs.length) return null;
          const color = ERA_COLORS[era];

          return (
            <div key={era} className="tl-era" style={{ animationDelay: `${eraIndex * 0.1}s` }}>
              {/* Era marker */}
              <div className="tl-era-marker" style={{ "--era-color": color }}>
                <div className="tl-era-dot" />
                <div className="tl-era-label">{era}</div>
              </div>

              {/* Language cards for this era */}
              <div className="tl-era-langs">
                {langs.map((lang, i) => (
                  <div
                    key={lang.id}
                    className={`tl-lang ${selected?.id === lang.id ? "tl-lang--active" : ""}`}
                    style={{ "--lang-color": lang.color, animationDelay: `${(eraIndex * 0.1) + (i * 0.05)}s` }}
                    onClick={() => setSelected(selected?.id === lang.id ? null : lang)}
                  >
                    <div className="tl-lang__glyphs">{lang.sample_glyphs}</div>
                    <div className="tl-lang__name">{lang.name}</div>
                    <div className="tl-lang__script">{lang.script}</div>
                    <div className="tl-lang__region">{lang.region}</div>
                    <div className="tl-lang__tags">
                      <span className="tag tag-gold">{lang.direction}</span>
                      <span className="tag" style={{
                        background: `${lang.color}18`,
                        color: lang.color,
                        border: `1px solid ${lang.color}40`,
                        fontSize: 9,
                        padding: "2px 8px",
                        borderRadius: 20,
                      }}>{lang.status}</span>
                    </div>

                    {/* Expanded detail */}
                    {selected?.id === lang.id && (
                      <div className="tl-lang__detail">
                        <hr style={{ border: "none", borderTop: "1px solid var(--border)", margin: "12px 0" }} />
                        <p style={{ fontSize: 13, color: "var(--text-dim)", lineHeight: 1.6, marginBottom: 8 }}>
                          {lang.description}
                        </p>
                        <p style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--aqua)", lineHeight: 1.5 }}>
                          📢 {lang.pronunciation_notes}
                        </p>
                        <p style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--text-muted)", marginTop: 6 }}>
                          {lang.family}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <style>{`
        .tl-root { display: flex; flex-direction: column; gap: 24px; }
        .tl-header { text-align: center; padding: 10px 0 20px; }
        .tl-title {
          font-family: var(--font-display);
          font-size: clamp(24px, 3.5vw, 44px);
          font-weight: 900;
          letter-spacing: 3px;
          color: var(--gold-light);
          margin-bottom: 10px;
        }
        .tl-sub { color: var(--text-dim); font-size: 15px; }
        .tl-container {
          position: relative;
          display: flex;
          flex-direction: column;
          gap: 48px;
          padding-left: 40px;
        }
        .tl-spine {
          position: absolute;
          left: 12px;
          top: 0; bottom: 0;
          width: 2px;
          background: linear-gradient(to bottom, var(--gold) 0%, var(--aqua) 50%, var(--gold) 100%);
          opacity: 0.25;
        }
        .tl-era { animation: fadeInUp 0.5s ease forwards; opacity: 0; }
        .tl-era-marker {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 20px;
          margin-left: -28px;
        }
        .tl-era-dot {
          width: 16px; height: 16px;
          border-radius: 50%;
          background: var(--era-color, var(--gold));
          box-shadow: 0 0 12px var(--era-color, var(--gold));
          flex-shrink: 0;
        }
        .tl-era-label {
          font-family: var(--font-display);
          font-size: 16px;
          font-weight: 600;
          letter-spacing: 2px;
          color: var(--era-color, var(--gold));
        }
        .tl-era-langs {
          display: flex;
          flex-wrap: wrap;
          gap: 14px;
        }
        .tl-lang {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 12px;
          padding: 16px;
          cursor: pointer;
          min-width: 200px;
          max-width: 280px;
          flex: 1;
          transition: all 0.25s;
          animation: fadeInUp 0.5s ease forwards;
          opacity: 0;
        }
        .tl-lang:hover {
          border-color: var(--lang-color, var(--gold));
          background: var(--surface2);
          transform: translateY(-3px);
          box-shadow: 0 8px 24px rgba(0,0,0,0.3);
        }
        .tl-lang--active {
          border-color: var(--lang-color, var(--gold)) !important;
          background: var(--surface2) !important;
          box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }
        .tl-lang__glyphs {
          font-size: 20px;
          letter-spacing: 2px;
          color: var(--lang-color, var(--gold));
          margin-bottom: 8px;
          filter: drop-shadow(0 0 4px var(--lang-color, var(--gold)));
        }
        .tl-lang__name {
          font-family: var(--font-display);
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 1px;
          color: var(--text);
          margin-bottom: 2px;
        }
        .tl-lang__script {
          font-family: var(--font-mono);
          font-size: 9px;
          letter-spacing: 1px;
          color: var(--aqua);
          margin-bottom: 3px;
          text-transform: uppercase;
        }
        .tl-lang__region { font-size: 11px; color: var(--text-muted); margin-bottom: 8px; }
        .tl-lang__tags { display: flex; gap: 4px; flex-wrap: wrap; }
        .tl-lang__detail { animation: fadeInUp 0.3s ease; }
      `}</style>
    </div>
  );
}

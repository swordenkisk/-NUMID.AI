/* pages/TranslatorPage.jsx — main translation interface */
import { useState, useEffect } from "react";
import { useLanguages, useTranslation } from "../hooks/useTranslation";
import LanguageCard from "../components/LanguageCard";
import TranslationResult from "../components/TranslationResult";

const STYLES = ["formal", "poetic", "conversational", "inscription"];

export default function TranslatorPage() {
  const { languages, fetchLanguages } = useLanguages();
  const { result, loading, error, translate } = useTranslation();

  const [text, setText] = useState("");
  const [selectedLang, setSelectedLang] = useState(null);
  const [style, setStyle] = useState("formal");
  const [filter, setFilter] = useState("");
  const [showAll, setShowAll] = useState(false);

  useEffect(() => { fetchLanguages(); }, [fetchLanguages]);

  const filteredLangs = languages.filter(l =>
    !filter ||
    l.name.toLowerCase().includes(filter.toLowerCase()) ||
    l.region.toLowerCase().includes(filter.toLowerCase()) ||
    l.family.toLowerCase().includes(filter.toLowerCase())
  );
  const displayedLangs = showAll ? filteredLangs : filteredLangs.slice(0, 12);

  const handleTranslate = async () => {
    if (!text.trim() || !selectedLang) return;
    await translate({ text, targetLangId: selectedLang.id, style });
  };

  const selectedResult = result;
  const selectedLangMeta = selectedLang;

  return (
    <div className="tp-root">

      {/* Header */}
      <div className="tp-hero">
        <div className="glyph-strip">𐤀𐤁𐤂 𒀭𒂗 𓂋𓏺 𐎠𐎡 ΑΒΓ ᚠᚢᚦ 𑀅𑀆 SPQR 𝋠𝋡 Ⲁⲃ 𐌰𐌱</div>
        <h1 className="tp-title">Speak Across Millennia</h1>
        <p className="tp-subtitle">
          Translate any modern text into 17 ancient languages — rendered in authentic scripts,
          with pronunciation guides and cultural context. Powered by Anthropic Claude.
        </p>
      </div>

      <div className="tp-layout">
        {/* Left: Input */}
        <div className="tp-input-col">

          {/* Text Input */}
          <div className="panel">
            <div className="section-label">Your Text</div>
            <textarea
              className="tp-textarea"
              placeholder="Type anything in any modern language…&#10;&#10;e.g. 'The stars guide us through the night' or&#10;'I am the king of kings' or&#10;'Love conquers all'"
              value={text}
              onChange={e => setText(e.target.value)}
              maxLength={2000}
            />
            <div className="tp-char-count">{text.length}/2000</div>

            {/* Style selector */}
            <div className="section-label" style={{ marginTop: 20 }}>Translation Style</div>
            <div className="tp-style-row">
              {STYLES.map(s => (
                <button
                  key={s}
                  className={`tp-style-btn ${style === s ? "active" : ""}`}
                  onClick={() => setStyle(s)}
                >
                  {s}
                </button>
              ))}
            </div>

            {/* Translate button */}
            <button
              className="btn btn-primary tp-translate-btn"
              onClick={handleTranslate}
              disabled={!text.trim() || !selectedLang || loading}
            >
              {loading ? (
                <><span className="loader" /> Consulting the ancients...</>
              ) : (
                <>𐤁 Translate into {selectedLang?.name || "Ancient Script"}</>
              )}
            </button>

            {error && (
              <div className="tp-error">
                ⚠ {error}
                {error.includes("API_KEY") && (
                  <div className="tp-error__hint">
                    Add your <code>ANTHROPIC_API_KEY</code> to <code>.env</code> and restart the backend.
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Result */}
          {selectedResult && (
            <div className="panel">
              <div className="section-label">
                Translation · {selectedLang?.name}
              </div>
              <TranslationResult result={selectedResult} lang={selectedLangMeta} />
            </div>
          )}
        </div>

        {/* Right: Language Picker */}
        <div className="tp-lang-col">
          <div className="panel" style={{ position: "sticky", top: 90 }}>
            <div className="section-label">Choose Ancient Language</div>

            <input
              className="tp-filter"
              placeholder="Search by name, region, family..."
              value={filter}
              onChange={e => setFilter(e.target.value)}
            />

            {selectedLang && (
              <div className="tp-selected-meta">
                <div style={{ color: selectedLang.color, fontSize: 28, letterSpacing: 3 }}>
                  {selectedLang.sample_glyphs}
                </div>
                <div style={{ fontFamily: "var(--font-display)", fontSize: 14, marginTop: 6 }}>
                  {selectedLang.name}
                </div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--text-muted)" }}>
                  {selectedLang.era}
                </div>
                <div style={{ fontSize: 12, color: "var(--text-dim)", marginTop: 6, lineHeight: 1.5 }}>
                  {selectedLang.description}
                </div>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--aqua)", marginTop: 8 }}>
                  {selectedLang.pronunciation_notes}
                </div>
              </div>
            )}

            <div className="tp-lang-grid">
              {displayedLangs.map(lang => (
                <LanguageCard
                  key={lang.id}
                  lang={lang}
                  selected={selectedLang?.id === lang.id}
                  onClick={() => setSelectedLang(lang)}
                />
              ))}
            </div>

            {filteredLangs.length > 12 && (
              <button
                className="btn btn-ghost"
                style={{ width: "100%", marginTop: 12, fontSize: 11 }}
                onClick={() => setShowAll(!showAll)}
              >
                {showAll ? "▲ Show less" : `▼ Show all ${filteredLangs.length} languages`}
              </button>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .tp-root { display: flex; flex-direction: column; gap: 32px; }
        .tp-hero { text-align: center; padding: 20px 0 10px; }
        .tp-title {
          font-family: var(--font-display);
          font-size: clamp(28px, 4vw, 52px);
          font-weight: 900;
          letter-spacing: 2px;
          background: linear-gradient(120deg, var(--gold-light), var(--aqua), var(--gold));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-size: 200%;
          animation: shimmer 4s linear infinite;
          margin-bottom: 12px;
        }
        .tp-subtitle {
          color: var(--text-dim);
          font-size: 16px;
          max-width: 640px;
          margin: 0 auto;
          line-height: 1.7;
        }
        .tp-layout {
          display: grid;
          grid-template-columns: 1fr 340px;
          gap: 24px;
          align-items: flex-start;
        }
        .tp-input-col { display: flex; flex-direction: column; gap: 20px; }
        .tp-lang-col { min-width: 0; }
        .tp-textarea {
          width: 100%;
          min-height: 160px;
          background: var(--surface2);
          border: 1px solid var(--border);
          border-radius: 8px;
          padding: 16px;
          color: var(--text);
          font-family: var(--font-body);
          font-size: 16px;
          line-height: 1.7;
          resize: vertical;
          outline: none;
          transition: border-color 0.2s;
        }
        .tp-textarea:focus { border-color: var(--border-glow); }
        .tp-textarea::placeholder { color: var(--text-muted); }
        .tp-char-count {
          font-family: var(--font-mono);
          font-size: 10px;
          color: var(--text-muted);
          text-align: right;
          margin-top: 4px;
        }
        .tp-style-row { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px; }
        .tp-style-btn {
          padding: 6px 16px;
          border-radius: 20px;
          border: 1px solid var(--border);
          background: transparent;
          color: var(--text-dim);
          font-family: var(--font-mono);
          font-size: 10px;
          letter-spacing: 1px;
          cursor: pointer;
          text-transform: uppercase;
          transition: all 0.2s;
        }
        .tp-style-btn:hover { border-color: var(--border-glow); color: var(--text); }
        .tp-style-btn.active {
          border-color: rgba(200,168,75,0.5);
          background: var(--gold-dim);
          color: var(--gold);
        }
        .tp-translate-btn { width: 100%; padding: 16px; font-size: 14px; letter-spacing: 3px; }
        .tp-error {
          margin-top: 14px;
          padding: 14px;
          background: rgba(217,95,122,0.08);
          border: 1px solid rgba(217,95,122,0.25);
          border-radius: 8px;
          color: var(--rose);
          font-size: 13px;
          line-height: 1.5;
        }
        .tp-error__hint { margin-top: 6px; color: var(--text-muted); font-size: 12px; }
        .tp-error code { font-family: var(--font-mono); color: var(--aqua); }
        .tp-filter {
          width: 100%;
          background: var(--surface2);
          border: 1px solid var(--border);
          border-radius: 8px;
          padding: 10px 14px;
          color: var(--text);
          font-family: var(--font-mono);
          font-size: 12px;
          outline: none;
          margin-bottom: 14px;
          transition: border-color 0.2s;
        }
        .tp-filter:focus { border-color: var(--border-glow); }
        .tp-filter::placeholder { color: var(--text-muted); }
        .tp-selected-meta {
          background: var(--gold-dim);
          border: 1px solid rgba(200,168,75,0.2);
          border-radius: 10px;
          padding: 16px;
          margin-bottom: 14px;
        }
        .tp-lang-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px;
          max-height: 480px;
          overflow-y: auto;
          padding-right: 4px;
        }
        @media (max-width: 900px) {
          .tp-layout { grid-template-columns: 1fr; }
          .tp-lang-col .panel { position: static; }
        }
      `}</style>
    </div>
  );
}

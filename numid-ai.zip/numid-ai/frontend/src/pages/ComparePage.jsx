/* pages/ComparePage.jsx — translate the same phrase into multiple ancient languages */
import { useState, useEffect } from "react";
import { useLanguages, useCompare } from "../hooks/useTranslation";

const QUICK_PHRASES = [
  "The stars are eternal",
  "I am the king",
  "Love and death",
  "In the beginning",
  "Water gives life",
  "The gods are watching",
  "Time flows like a river",
  "Knowledge is power",
];

export default function ComparePage() {
  const { languages, fetchLanguages } = useLanguages();
  const { results, loading, error, compare } = useCompare();

  const [text, setText] = useState("");
  const [selected, setSelected] = useState([]);

  useEffect(() => { fetchLanguages(); }, [fetchLanguages]);

  const toggleLang = (id) => {
    setSelected(prev =>
      prev.includes(id)
        ? prev.filter(x => x !== id)
        : prev.length < 6 ? [...prev, id] : prev
    );
  };

  const handleCompare = async () => {
    if (!text.trim() || selected.length < 2) return;
    await compare({ text, languageIds: selected });
  };

  const getLang = (id) => languages.find(l => l.id === id);

  return (
    <div className="cp-root">
      <div className="cp-header">
        <h1 className="cp-title">Cross-Language Compare</h1>
        <p className="cp-sub">See the same phrase written in up to 6 ancient scripts simultaneously.</p>
      </div>

      <div className="panel cp-input-panel">
        <div className="section-label">Phrase to Compare</div>
        <div className="cp-quick">
          {QUICK_PHRASES.map(p => (
            <button key={p} className="cp-quick-btn" onClick={() => setText(p)}>{p}</button>
          ))}
        </div>
        <div className="cp-input-row">
          <input
            className="cp-input"
            placeholder="Enter a phrase..."
            value={text}
            onChange={e => setText(e.target.value)}
            maxLength={300}
          />
          <button
            className="btn btn-primary"
            onClick={handleCompare}
            disabled={!text.trim() || selected.length < 2 || loading}
            style={{ whiteSpace: "nowrap", padding: "13px 24px" }}
          >
            {loading ? <><span className="loader" /> Translating...</> : "⬡ Compare"}
          </button>
        </div>
        {selected.length < 2 && (
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--text-muted)", marginTop: 8 }}>
            Select 2–6 languages below
          </div>
        )}
        {error && <div className="tp-error" style={{ marginTop: 12 }}>⚠ {error}</div>}
      </div>

      {/* Language multi-select */}
      <div className="panel">
        <div className="section-label">
          Select Languages ({selected.length}/6)
        </div>
        <div className="cp-lang-grid">
          {languages.map(lang => {
            const active = selected.includes(lang.id);
            return (
              <button
                key={lang.id}
                className={`cp-lang-chip ${active ? "active" : ""}`}
                style={{ "--lc": lang.color }}
                onClick={() => toggleLang(lang.id)}
                disabled={!active && selected.length >= 6}
              >
                <span className="cp-chip-glyph">{lang.sample_glyphs[0]}</span>
                <span>{lang.name}</span>
                {active && <span className="cp-chip-check">✓</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Results */}
      {results.length > 0 && (
        <div className="cp-results">
          <div className="section-label">{text} — in {results.length} ancient languages</div>
          <div className="cp-results-grid">
            {results.map((r, i) => {
              const langId = r.language_meta?.id || selected[i];
              const langMeta = r.language_meta || getLang(langId);
              const isRTL = langMeta?.direction === "rtl";
              return (
                <div
                  key={i}
                  className="cp-result-card animate-fadeInUp"
                  style={{ "--lc": langMeta?.color || "var(--gold)", animationDelay: `${i * 0.1}s` }}
                >
                  <div className="cp-result-lang">
                    <span className="cp-result-glyph">{langMeta?.sample_glyphs?.[0]}</span>
                    <div>
                      <div className="cp-result-name">{langMeta?.name}</div>
                      <div className="cp-result-era">{langMeta?.era}</div>
                    </div>
                  </div>
                  <div
                    className={`script-display ${isRTL ? "rtl" : ""}`}
                    style={{ fontSize: "clamp(18px, 2.5vw, 32px)", color: langMeta?.color || "var(--gold)" }}
                  >
                    {r.script_rendering || r.translated_text}
                  </div>
                  <div className="transliteration" style={{ fontSize: 12 }}>/{r.transliteration}/</div>
                  {r.cultural_notes && (
                    <div className="cp-result-note">{r.cultural_notes.slice(0, 120)}...</div>
                  )}
                  <div className="tag" style={{
                    marginTop: 10,
                    background: `${langMeta?.color}18`,
                    color: langMeta?.color,
                    border: `1px solid ${langMeta?.color}40`,
                    fontSize: 9,
                    letterSpacing: 1,
                  }}>
                    {r.confidence?.toUpperCase()} CONFIDENCE
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <style>{`
        .cp-root { display: flex; flex-direction: column; gap: 24px; }
        .cp-header { text-align: center; padding: 10px 0 20px; }
        .cp-title {
          font-family: var(--font-display);
          font-size: clamp(24px, 3.5vw, 44px);
          font-weight: 900;
          letter-spacing: 3px;
          color: var(--aqua);
          margin-bottom: 10px;
        }
        .cp-sub { color: var(--text-dim); font-size: 15px; }
        .cp-input-panel { display: flex; flex-direction: column; gap: 12px; }
        .cp-quick { display: flex; flex-wrap: wrap; gap: 6px; }
        .cp-quick-btn {
          padding: 5px 12px;
          border-radius: 20px;
          border: 1px solid var(--border);
          background: transparent;
          color: var(--text-muted);
          font-size: 11px;
          cursor: pointer;
          font-family: var(--font-body);
          transition: all 0.2s;
        }
        .cp-quick-btn:hover {
          border-color: var(--border-glow);
          color: var(--text);
          background: var(--surface2);
        }
        .cp-input-row { display: flex; gap: 12px; }
        .cp-input {
          flex: 1;
          background: var(--surface2);
          border: 1px solid var(--border);
          border-radius: 8px;
          padding: 13px 16px;
          color: var(--text);
          font-family: var(--font-body);
          font-size: 16px;
          outline: none;
          transition: border-color 0.2s;
        }
        .cp-input:focus { border-color: var(--border-glow); }
        .cp-input::placeholder { color: var(--text-muted); }
        .cp-lang-grid {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }
        .cp-lang-chip {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 7px 14px;
          border-radius: 20px;
          border: 1px solid var(--border);
          background: transparent;
          color: var(--text-dim);
          font-family: var(--font-display);
          font-size: 11px;
          letter-spacing: 1px;
          cursor: pointer;
          transition: all 0.2s;
        }
        .cp-lang-chip:hover:not(:disabled) {
          border-color: var(--lc, var(--gold));
          color: var(--lc, var(--gold));
          background: color-mix(in srgb, var(--lc, var(--gold)) 10%, transparent);
        }
        .cp-lang-chip.active {
          border-color: var(--lc, var(--gold));
          color: var(--lc, var(--gold));
          background: color-mix(in srgb, var(--lc, var(--gold)) 12%, transparent);
        }
        .cp-lang-chip:disabled { opacity: 0.3; cursor: not-allowed; }
        .cp-chip-glyph { font-size: 16px; }
        .cp-chip-check { font-size: 10px; }
        .cp-results { display: flex; flex-direction: column; gap: 14px; }
        .cp-results-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
          gap: 16px;
        }
        .cp-result-card {
          background: var(--surface);
          border: 1px solid rgba(255,255,255,0.06);
          border-radius: 14px;
          padding: 20px;
          border-top: 3px solid var(--lc, var(--gold));
          animation: fadeInUp 0.5s ease forwards;
          opacity: 0;
        }
        .cp-result-lang { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
        .cp-result-glyph { font-size: 28px; color: var(--lc, var(--gold)); filter: drop-shadow(0 0 6px var(--lc, var(--gold))); }
        .cp-result-name { font-family: var(--font-display); font-size: 13px; color: var(--text); font-weight: 600; }
        .cp-result-era { font-family: var(--font-mono); font-size: 9px; color: var(--text-muted); }
        .cp-result-note { font-size: 11px; color: var(--text-muted); margin-top: 8px; line-height: 1.5; font-style: italic; }
      `}</style>
    </div>
  );
}

import { useState, useEffect, useRef } from "react";
import TranslatorPage from "./pages/TranslatorPage";
import TimelinePage from "./pages/TimelinePage";
import ComparePage from "./pages/ComparePage";
import "./styles/globals.css";

export default function App() {
  const [page, setPage] = useState("translate");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setTimeout(() => setMounted(true), 100);
  }, []);

  return (
    <div className={`app ${mounted ? "mounted" : ""}`}>
      <StarField />
      <Nav page={page} setPage={setPage} />
      <main className="main-content">
        {page === "translate" && <TranslatorPage />}
        {page === "timeline" && <TimelinePage />}
        {page === "compare" && <ComparePage />}
      </main>
      <footer className="footer">
        <span className="footer-glyph">𐤀𒀭𓂋𐎠ΑᚠΑ</span>
        <span>NUMID.AI · Ancient languages, future minds · Powered by Anthropic Claude</span>
        <span className="footer-glyph">𐤀𒀭𓂋𐎠ΑᚠΑ</span>
      </footer>
    </div>
  );
}

function Nav({ page, setPage }) {
  const navItems = [
    { id: "translate", label: "Translate", glyph: "𐤁" },
    { id: "timeline", label: "Timeline", glyph: "𓂋" },
    { id: "compare", label: "Compare", glyph: "𒀭" },
  ];

  return (
    <nav className="nav">
      <div className="nav-logo" onClick={() => setPage("translate")}>
        <span className="logo-glyph">𐤀</span>
        <span className="logo-text">NUMID<span className="logo-dot">.</span>AI</span>
        <span className="logo-tag">ancient × future</span>
      </div>
      <div className="nav-links">
        {navItems.map(item => (
          <button
            key={item.id}
            className={`nav-link ${page === item.id ? "active" : ""}`}
            onClick={() => setPage(item.id)}
          >
            <span className="nav-glyph">{item.glyph}</span>
            {item.label}
          </button>
        ))}
      </div>
      <div className="nav-badge">
        <span className="badge-dot" />
        Claude Sonnet
      </div>
    </nav>
  );
}

function StarField() {
  const canvasRef = useRef();

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    let animId;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const stars = Array.from({ length: 120 }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      r: Math.random() * 1.2 + 0.2,
      alpha: Math.random(),
      speed: Math.random() * 0.003 + 0.001,
    }));

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      stars.forEach(s => {
        s.alpha += s.speed;
        if (s.alpha > 1 || s.alpha < 0) s.speed *= -1;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(180, 210, 255, ${s.alpha * 0.6})`;
        ctx.fill();
      });
      animId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="starfield" />;
}

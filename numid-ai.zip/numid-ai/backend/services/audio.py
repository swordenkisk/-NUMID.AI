"""
services/audio.py
Text-to-speech service for ancient language pronunciation.
Uses gTTS for romanized/transliterated forms since ancient languages
have no native TTS engines.
"""

import os
import io
import hashlib
import asyncio
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

load_dotenv()

AUDIO_DIR = Path(os.getenv("AUDIO_OUTPUT_DIR", "audio_outputs"))
AUDIO_DIR.mkdir(parents=True, exist_ok=True)

TTS_PROVIDER = os.getenv("TTS_PROVIDER", "offline")


def _audio_key(text: str, lang: str) -> str:
    return hashlib.md5(f"{text}|{lang}".encode()).hexdigest()[:16]


async def generate_pronunciation_audio(
    transliteration: str,
    language_id: str,
    slow: bool = True,
) -> Optional[bytes]:
    """
    Generate audio for the transliterated (romanized) form of ancient text.
    Returns audio bytes (MP3) or None if generation fails.
    """
    cache_path = AUDIO_DIR / f"{_audio_key(transliteration, language_id)}.mp3"
    if cache_path.exists():
        return cache_path.read_bytes()

    try:
        if TTS_PROVIDER == "google":
            return await _gtts_generate(transliteration, slow, cache_path)
        else:
            return await _gtts_generate(transliteration, slow, cache_path)
    except Exception as e:
        print(f"[Audio] TTS generation failed: {e}")
        return None


async def _gtts_generate(text: str, slow: bool, cache_path: Path) -> Optional[bytes]:
    """Use gTTS (free Google TTS) for pronunciation."""
    try:
        from gtts import gTTS

        def _sync_gen():
            tts = gTTS(text=text, lang="en", slow=slow)
            buf = io.BytesIO()
            tts.write_to_fp(buf)
            buf.seek(0)
            data = buf.read()
            cache_path.write_bytes(data)
            return data

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _sync_gen)
    except Exception as e:
        print(f"[gTTS] Failed: {e}")
        return None


def audio_file_url(transliteration: str, language_id: str) -> Optional[str]:
    """Return URL path if cached audio exists."""
    key = _audio_key(transliteration, language_id)
    path = AUDIO_DIR / f"{key}.mp3"
    return f"/audio/{key}.mp3" if path.exists() else None

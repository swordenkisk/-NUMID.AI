"""
services/translator.py
Core AI translation engine — uses Anthropic Claude to translate modern text
into ancient languages with scholarly accuracy, script rendering, and
phonetic transcription.
"""

import os
import json
import hashlib
import asyncio
from typing import Optional
from cachetools import TTLCache

import anthropic
from dotenv import load_dotenv

load_dotenv()

_client: Optional[anthropic.AsyncAnthropic] = None
_cache: TTLCache = TTLCache(maxsize=512, ttl=3600)  # 1-hour cache


def get_client() -> anthropic.AsyncAnthropic:
    global _client
    if _client is None:
        api_key = os.getenv("ANTHROPIC_API_KEY", "")
        if not api_key or api_key == "your_anthropic_api_key_here":
            raise ValueError(
                "ANTHROPIC_API_KEY not set. Add it to your .env file."
            )
        _client = anthropic.AsyncAnthropic(api_key=api_key)
    return _client


def _cache_key(text: str, target_lang_id: str, source_lang: str) -> str:
    raw = f"{text}|{target_lang_id}|{source_lang}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


SYSTEM_PROMPT = """You are Numid — an elite ancient languages scholar and AI.
You hold deep expertise in all ancient writing systems: Phoenician, Sumerian cuneiform, 
Akkadian, Ancient Egyptian hieroglyphics, Ugaritic, Imperial Aramaic, Old Persian cuneiform,
Linear B, Gothic, Etruscan, Classic Maya glyphs, Vedic Sanskrit, Classical Latin,
Ancient Greek, Old Norse runes, Coptic, and Proto-Sinaitic.

Your mission: translate modern text into the requested ancient language with maximum
scholarly fidelity. You must:

1. TRANSLATE the meaning as accurately as possible into the target language.
   For extinct/reconstructed languages, use the best attested forms.
   For logographic scripts, choose signs that capture the semantic meaning.

2. RENDER in the authentic script/alphabet of that language using proper Unicode characters.

3. TRANSLITERATE into a modern phonetic representation (IPA or scholarly standard).

4. EXPLAIN the translation choices, script direction, and any cultural nuances.

5. PRONUNCIATION GUIDE: Break down each word/sign with its approximate sound.

Always respond ONLY in this exact JSON format — no markdown, no preamble:
{
  "original_text": "...",
  "target_language": "...",
  "translated_text": "...",
  "script_rendering": "...",
  "transliteration": "...",
  "ipa_pronunciation": "...",
  "word_breakdown": [
    {
      "original_word": "...",
      "translation": "...",
      "script": "...",
      "phonetic": "...",
      "notes": "..."
    }
  ],
  "cultural_notes": "...",
  "script_direction": "ltr|rtl|btt",
  "confidence": "high|medium|low",
  "confidence_reason": "...",
  "fun_fact": "..."
}

For languages where exact translation is impossible (e.g., modern concepts in Sumerian),
explain what the closest equivalent would be and use circumlocution or logograms.
Be honest about uncertainty — ancient languages involve scholarly reconstruction."""


async def translate(
    text: str,
    target_language_id: str,
    target_language_name: str,
    source_language: str = "auto",
    style: str = "formal",
) -> dict:
    """
    Translate text into an ancient language using Claude.
    Returns structured JSON with script, phonetics, and notes.
    """
    cache_key = _cache_key(text, target_language_id, source_language)
    if cache_key in _cache:
        return _cache[cache_key]

    client = get_client()

    user_message = f"""Translate the following text into {target_language_name}.

Source text: "{text}"
Source language: {source_language} (auto-detect if 'auto')
Translation style: {style} (options: formal, poetic, conversational, inscription)

Target ancient language: {target_language_name} (id: {target_language_id})

Provide the full translation with script rendering, phonetics, word breakdown, 
and cultural context as specified."""

    response = await client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=int(os.getenv("MAX_TOKENS_PER_REQUEST", 4096)),
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_message}],
    )

    raw = response.content[0].text.strip()

    # Strip any accidental markdown fences
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip().rstrip("```").strip()

    result = json.loads(raw)
    _cache[cache_key] = result
    return result


async def get_pronunciation_guide(
    script_text: str,
    language_id: str,
    language_name: str,
) -> dict:
    """
    Generate a detailed pronunciation guide for already-translated script text.
    """
    client = get_client()

    prompt = f"""Create a detailed pronunciation guide for this {language_name} text: "{script_text}"

Respond ONLY in JSON:
{{
  "language": "{language_name}",
  "text": "{script_text}",
  "syllables": ["list", "of", "syllables"],
  "phoneme_guide": [
    {{"sign": "...", "sound": "...", "description": "...", "english_example": "..."}}
  ],
  "rhythm_pattern": "...",
  "stress_notes": "...",
  "audio_tips": "..."
}}"""

    response = await client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}],
    )

    raw = response.content[0].text.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip().rstrip("```").strip()
    return json.loads(raw)


async def compare_across_languages(
    text: str,
    language_ids: list,
) -> list:
    """
    Translate same text into multiple ancient languages simultaneously.
    Uses asyncio.gather for parallel Claude calls.
    """
    from backend.models.languages import LANGUAGES_BY_ID

    tasks = []
    for lang_id in language_ids:
        lang = LANGUAGES_BY_ID.get(lang_id)
        if lang:
            tasks.append(translate(text, lang.id, lang.name))

    results = await asyncio.gather(*tasks, return_exceptions=True)
    return [r for r in results if not isinstance(r, Exception)]

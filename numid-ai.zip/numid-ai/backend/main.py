"""
backend/main.py
Numid.ai — FastAPI application entry point.
Ancient language translation platform powered by Anthropic Claude.
"""

import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from dotenv import load_dotenv

load_dotenv()

from backend.routers.translate import router as translate_router

# ── Config ────────────────────────────────────────────────────────────────────

HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", 8000))
DEBUG = os.getenv("DEBUG", "False").lower() == "true"
ALLOWED_ORIGINS = os.getenv(
    "ALLOWED_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000"
).split(",")
AUDIO_DIR = Path(os.getenv("AUDIO_OUTPUT_DIR", "audio_outputs"))
AUDIO_DIR.mkdir(parents=True, exist_ok=True)

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Numid.ai API",
    description="Ancient language translation platform — bridging past and future through AI.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve generated audio files
app.mount("/audio", StaticFiles(directory=str(AUDIO_DIR)), name="audio")

# ── Routers ───────────────────────────────────────────────────────────────────

app.include_router(translate_router)

# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    return {
        "name": "Numid.ai",
        "tagline": "Ancient languages, future minds.",
        "version": "1.0.0",
        "powered_by": "Anthropic Claude",
        "languages_supported": 17,
        "docs": "/docs",
    }


@app.get("/health")
async def health():
    return {"status": "ok"}


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host=HOST, port=PORT, reload=DEBUG)

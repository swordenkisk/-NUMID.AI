"""
routers/translate.py
FastAPI router for all translation endpoints.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Optional, List
import asyncio

from backend.services.translator import translate, get_pronunciation_guide, compare_across_languages
from backend.models.languages import ANCIENT_LANGUAGES, LANGUAGES_BY_ID, ERA_GROUPS

router = APIRouter(prefix="/api/v1", tags=["translation"])


# ── Request / Response Models ─────────────────────────────────────────────────

class TranslateRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=2000)
    target_language_id: str
    source_language: str = "auto"
    style: str = "formal"


class PronunciationRequest(BaseModel):
    script_text: str
    language_id: str


class CompareRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=500)
    language_ids: List[str] = Field(..., min_items=2, max_items=6)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/languages")
async def list_languages():
    """Return all supported ancient languages with metadata."""
    return {
        "languages": [lang.model_dump() for lang in ANCIENT_LANGUAGES],
        "total": len(ANCIENT_LANGUAGES),
        "era_groups": ERA_GROUPS,
    }


@router.get("/languages/{lang_id}")
async def get_language(lang_id: str):
    """Return metadata for a specific language."""
    lang = LANGUAGES_BY_ID.get(lang_id)
    if not lang:
        raise HTTPException(status_code=404, detail=f"Language '{lang_id}' not found.")
    return lang.model_dump()


@router.post("/translate")
async def translate_text(req: TranslateRequest):
    """
    Translate text into an ancient language.
    Returns script rendering, transliteration, IPA, word breakdown, and cultural notes.
    """
    lang = LANGUAGES_BY_ID.get(req.target_language_id)
    if not lang:
        raise HTTPException(status_code=404, detail=f"Language '{req.target_language_id}' not supported.")

    try:
        result = await translate(
            text=req.text,
            target_language_id=lang.id,
            target_language_name=lang.name,
            source_language=req.source_language,
            style=req.style,
        )
        result["language_meta"] = lang.model_dump()
        return {"success": True, "data": result}
    except ValueError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Translation failed: {str(e)}")


@router.post("/pronunciation")
async def pronunciation_guide(req: PronunciationRequest):
    """Generate a detailed sign-by-sign pronunciation guide."""
    lang = LANGUAGES_BY_ID.get(req.language_id)
    if not lang:
        raise HTTPException(status_code=404, detail=f"Language '{req.language_id}' not found.")

    try:
        guide = await get_pronunciation_guide(
            script_text=req.script_text,
            language_id=lang.id,
            language_name=lang.name,
        )
        return {"success": True, "data": guide}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/compare")
async def compare_languages(req: CompareRequest):
    """Translate the same text into multiple ancient languages in parallel."""
    invalid = [lid for lid in req.language_ids if lid not in LANGUAGES_BY_ID]
    if invalid:
        raise HTTPException(status_code=400, detail=f"Unknown language IDs: {invalid}")

    try:
        results = await compare_across_languages(req.text, req.language_ids)
        return {"success": True, "text": req.text, "translations": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/timeline")
async def language_timeline():
    """Return languages organized by historical era for timeline display."""
    timeline = []
    for era, lang_ids in ERA_GROUPS.items():
        langs = [LANGUAGES_BY_ID[lid].model_dump() for lid in lang_ids if lid in LANGUAGES_BY_ID]
        timeline.append({"era": era, "languages": langs})
    return {"timeline": timeline}
